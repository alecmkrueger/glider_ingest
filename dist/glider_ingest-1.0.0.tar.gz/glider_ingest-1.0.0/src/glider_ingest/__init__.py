'''
Module to ingest and process raw glider data into NetCDF files
'''